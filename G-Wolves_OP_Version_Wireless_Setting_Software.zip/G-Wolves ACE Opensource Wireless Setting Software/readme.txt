                                                          Instructions for g-wolves parameter setting software

After you plug in the mouse receiver and open mouse power switch, please run 'G-Wolves OpenSource Wireless Setting Software' directly. 

G-Wolves

support@g-wolves.com