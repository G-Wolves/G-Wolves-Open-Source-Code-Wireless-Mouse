English：
The dongle is erased by sending an erase command through the driver. The mouse is erased by pressing the front side button on the left while holding down the DPI button. Both the dongle and the mouse must be erased before proceeding with the next connection operation.
Chinese：
dongle通过驱动发送erase指令擦除；鼠标通过左侧前键+长按dpi键进行擦除，必须dongle和鼠标都擦除才可进行下一次连接操作。
