1、To clear the dongle, connect it to the computer and directly use "erase dongle.bat".

2、To clear the mouse, first connect it to the computer via USB, then use "erase mouse.bat" to clear it.

3、It is essential to ensure that only one cleared mouse and one cleared dongle are present in the entire clearing environment. Otherwise, pairing conflicts may occur, leading to connection confusion.